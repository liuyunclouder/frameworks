//
//  ORStackViewController.h
//  Pods
//
//  Created by Dzianis Lebedzeu on 5/5/15.
//
//

#import "ORStackScrollView.h"

@interface ORStackViewController : UIViewController

@property (nonatomic, readonly) ORStackScrollView *scrollView;
@property (nonatomic, readonly) ORStackView *stackView;

@end
